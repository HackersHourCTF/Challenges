Bike '0' bike

Lost my spare parts while dismandling my tenr. Find the missing case to fix it and impress me.

Flag format: THM{missing-case}
