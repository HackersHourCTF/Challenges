import java.util.Scanner;

public class getsetgo {
    
public static final int Flag_LENGTH = 8;

public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print(
                "1. A Flag must have at least eight characters.\n" +
                "2. A Flag consists of only letters and digits.\n" +
                "3. A Flag must contain at least two digits \n" +
                "Input a Flag ");
        String s = input.nextLine();

        if (is_Valid_Flag(s)) {
            System.out.println(" h4ck_7h3_pl4n3t  ");
        } else {
            System.out.println("Not a valid Flag: " + s);
        }

    }

    public static boolean is_Valid_Flag(String Flag) {

        if (Flag.length() < Flag_LENGTH) return false;

        int charCount = 0;
        int numCount = 0;
        for (int i = 0; i < Flag.length(); i++) {

            char ch = Flag.charAt(i);

            if (is_Numeric(ch)) numCount++;
            else if (is_Letter(ch)) charCount++;
            else return false;
        }


        return (charCount >= 2 && numCount >= 2);
    }

    public static boolean is_Letter(char ch) {
        ch = Character.toUpperCase(ch);
        return (ch >= 'A' && ch <= 'Z');
    }


    public static boolean is_Numeric(char ch) {

        return (ch >= '0' && ch <= '9');
    }

}
